echo "Enter 3 numbers"
echo "a: "
read a
echo "b: "
read b
echo "c: "
read c
if [ $a -gt $b ] && [ $a -gt $c ]
then
echo "a is greatest"
elif [ $b -gt $a ] && [ $b -gt $c ]
then
echo "b is greatest"
elif [ $c -gt $a ] && [ $c -gt $b ]
then
echo "c is greatest"
fi
