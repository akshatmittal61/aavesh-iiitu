#include <bits/stdc++.h>

using namespace std;

int main()
{
    double a, b, c;
    cin >> a >> b >> c;
    if (a == 0)
        cout << "a can't be 0";
    else
    {
        double D = b * b - 4 * a * c;
        if (D < 0)
            cout << "Two Imaginary roots" << endl;
        else if (D == 0)
            cout << "One real root" << endl;
        else
            cout << "Two real roots" << endl;
    }
    return 0;
}