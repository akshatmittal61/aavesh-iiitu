#include <bits/stdc++.h>
using namespace std;

int main()
{
    cout << endl;
    long long n;
    cout << " Enter KLOC: ";
    cin >> n;
    double oe, se, ee, st, ot, et, a1, a2, a3;

    oe = pow(n, 1.05);
    se = pow(n, 1.12);
    ee = pow(n, 1.20);

    ot = 2.0 * pow(oe, 0.38);
    st = 2.0 * pow(se, 0.35);
    et = 2.0 * pow(ee, 0.32);

    a1 = (double)(oe / ot);
    a2 = (double)(se / st);
    a3 = (double)(ee / et);

    cout << "\n Average no. of people in organic: " << ceil(a1);
    cout << "\n Average no. of people in semi-detached: " << ceil(a2);
    cout << "\n Average no. of people in embedded: " << ceil(a3);
    cout << endl;
    return 0;
}