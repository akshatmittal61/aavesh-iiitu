#include <iostream>
#include <math.h>
using namespace std;

string modelType(long long LOC)
{
    if (LOC >= 1 && LOC <= 100)
        return "Organic";
    else if (LOC >= 101 && LOC <= 200)
        return "Semi-Detached";
    else
        return "Embedded";
}

double Calc_Effort(long long LOC)
{
    if (modelType(LOC) == "Organic")
        return 2.4 * pow(LOC, 1.05) * 0.001;
    else if (modelType(LOC) == "Semi-Detached")
        return 3.0 * pow(LOC, 1.12) * 0.001;
    else
        return 3.6 * pow(LOC, 1.20) * 0.001;
}

double Calc_T_Dev(long long LOC)
{
    double effort = Calc_Effort(LOC);
    if (modelType(LOC) == "Organic")
        return 2.5 * pow(effort, 0.38);
    else if (modelType(LOC) == "Semi-Detached")
        return 2.5 * pow(effort, 0.35);
    else
        return 2.5 * pow(effort, 0.32);
}

int main()
{
    double KLOC;
    cout << endl;
    cout << "\n Line of Code: ";
    cin >> KLOC;
    double effort = Calc_Effort(KLOC), T_Dev = Calc_T_Dev(KLOC);
    cout << "\n Model Type: " << modelType(KLOC);
    cout << "\n Effort: " << Calc_Effort(KLOC);
    cout << "\n Development Time: " << Calc_T_Dev(KLOC);

    double AME, ACT, SDE, t;
    double me, total_effort;

    cout << "\n Enter software developement effort, SDE in PM: ";
    cin >> SDE;
    cout << "\n Enter Annual Change Traffic, ACT (in %): ";
    cin >> ACT;
    ACT /= 100;
    cout << "\n Enter project life-time, t in years: ";
    cin >> t;

    AME = ACT * SDE;
    me = t * AME;
    total_effort = SDE + me;

    cout << "\n Annual Maintenance Effort (AME) = " << AME << " PM";
    cout << "\n Maintenance effort for " << t << " years = " << me << " PM";
    cout << "\n Total effort = " << total_effort << " PM";
    cout << endl;
    return 0;
}