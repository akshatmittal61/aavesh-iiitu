#! /usr/bin/bash

# ECHO cmnd
# echo Hello World!

#variables
# NAME="Akshat"
# echo "I am $NAME"
# echo "I am ${NAME}"

#input
# read -p "Enter your name: " NAME
# echo "Hello ${NAME}, its nice to meet you"

#if else
# if [ "$NAME" == "Anshika" ]
# then echo "Great to meet you"
# elif [ "$NAME" == "Sneha" ]
# then echo "Nice to meet you"
# else echo "Fuck Off"
# fi

#comparisons
# a=3
# b=5
# if [ "$a" -gt "$b" ]
# then echo "a>b"
# else echo "a<=b"
# fi

#file handling
# FILE="test"
# if [ -e "$FILE" ]
# then echo "$FILE It is a file"
# else echo "$FILE It is not a file"
# fi

#case
# read -p "Are you 18? " ans
# case "$ans" in
# [yY] | [yY][eE][sS])
# echo "Fuck"
# ;;
# [nN] | [nN][oO])
# echo "Virgin"
# ;;
# *)
# echo "Enter age"
# ;;
# esac

# NAMES="Akshat Sneha Sambhav Anshika"
# for NAME in $NAMES
# do
# echo "Hello $NAME"
# done

# n=1
# FILES=$(ls *.html)
# NEW=".txt"
# for FILE in $FILES
# do
# echo "Renaming $FILE to new-$FILE"
# mv $FILE $n$NEW
# n=$n+1
# done

# LINE=1
# while read -r CURRENT_LINE
# do
# echo "$LINE: $CURRENT_LINE"
# ((LINE++))
# done < "./1.txt"

#functions
# function sayHello()
# {
#     echo "Hello World"
# }
# sayHello

# function greet()
# {
#     echo "Hello, I am $1 and $2"
# }
# greet "Akshat" "Anshika"

mkdir Hello
cd Hello
touch word.txt
echo "Hello World" >> word.txt
echo "Created and edited, here it goes"
cat word.txt