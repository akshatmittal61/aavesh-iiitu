#include <iostream>
#include <math.h>
using namespace std;

string modelType(int LOC)
{
    if (LOC >= 1 && LOC <= 100)
        return "Organic";
    else if (LOC >= 101 && LOC <= 200)
        return "Semi-Detached";
    else
        return "Embedded";
}

float Calc_Effort(int LOC)
{
    if (modelType(LOC) == "Organic")
        return 2.4 * pow(LOC, 1.05) * 0.001;
    else if (modelType(LOC) == "Semi-Detached")
        return 3.0 * pow(LOC, 1.12) * 0.001;
    else
        return 3.6 * pow(LOC, 1.20) * 0.001;
}

float Calc_T_Dev(int LOC)
{
    float effort = Calc_Effort(LOC);
    if (modelType(LOC) == "Organic")
        return 2.5 * pow(effort, 0.38);
    else if (modelType(LOC) == "Semi-Detached")
        return 2.5 * pow(effort, 0.35);
    else
        return 2.5 * pow(effort, 0.32);
}

int main()
{
    int LOC;
    cout << endl;
    cout << "\n Line of Code: ";
    cin >> LOC;
    float effort, T_Dev;
    cout << "\n Model Type: " << modelType(LOC);
    cout << "\n Effort: " << Calc_Effort(LOC);
    cout << "\n Development Time: " << Calc_T_Dev(LOC);
    cout << endl
         << endl;
    return 0;
}