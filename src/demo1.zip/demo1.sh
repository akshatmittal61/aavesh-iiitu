echo "Enter a number"
read x
if [ $x -ge 0 ]
then
echo "positive"
else
echo "negative"
fi
